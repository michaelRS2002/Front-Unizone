const Logo = () => {
  return <div className="logo">UNIZONE</div>;
};
export default Logo;
