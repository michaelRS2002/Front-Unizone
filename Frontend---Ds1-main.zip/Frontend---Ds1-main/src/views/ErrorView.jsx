

const ErrorView = () => {
  return (
    <div style={{ height: "50vh" }} className="sub-container">
      <h1>404</h1>
      <h4>Oops Page Not Found!</h4>
    </div>
  );
};
export default ErrorView;
