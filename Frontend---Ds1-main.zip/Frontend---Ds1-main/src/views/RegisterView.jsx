import React from "react";
import RegisterForm from "../components/NavBar/Register/RegisterForm"; // Importación correcta
 

const RegisterView = () => {
  return (
    <div>
      <main>
        <RegisterForm />
      </main>
    </div>
  );
};

export default RegisterView;

