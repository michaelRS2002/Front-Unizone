import LoginForm from '../components/NavBar/loginForm/LoginForm';
const LoginView = () => {
    return (
      <div>
        <main>
          <LoginForm></LoginForm>
        </main>
      </div>
    );
  };
  export default LoginView;