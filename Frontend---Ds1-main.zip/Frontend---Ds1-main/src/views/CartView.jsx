import Order from "../components/Cart/Order";

const CartView = () => {
  return (
    <div>
      <main>
        <Order></Order>
      </main>
    </div>
  );
};
export default CartView;
